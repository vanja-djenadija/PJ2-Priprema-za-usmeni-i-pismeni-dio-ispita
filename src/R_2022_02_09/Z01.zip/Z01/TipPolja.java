package R20220209.Z01;

public enum TipPolja {
    OBICNO,
    NERAVNO,
    KLIZAVO
}