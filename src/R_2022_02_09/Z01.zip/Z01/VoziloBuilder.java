package R20220209.Z01;

import java.util.List;

public interface VoziloBuilder {

    Vozilo build(List<String> linije);
}