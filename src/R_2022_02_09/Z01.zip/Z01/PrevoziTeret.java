package R20220209.Z01;

public interface PrevoziTeret {
}