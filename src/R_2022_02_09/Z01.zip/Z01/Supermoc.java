package R20220209.Z01;

public class Supermoc {

    String ime;

    public Supermoc(String ime) {
        this.ime = ime;
    }

    @Override
    public String toString() {
        return ime;
    }
}