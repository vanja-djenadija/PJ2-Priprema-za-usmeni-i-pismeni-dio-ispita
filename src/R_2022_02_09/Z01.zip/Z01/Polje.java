package R20220209.Z01;

public class Polje implements Element {
    @Override
    public String toString() {
        return getClass().getSimpleName();
    }
}