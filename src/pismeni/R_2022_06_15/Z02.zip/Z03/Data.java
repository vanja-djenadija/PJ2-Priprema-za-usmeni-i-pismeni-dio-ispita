package R20220615.Z03;

public interface Data<T, V> {
    T getType();

    V getValue();

}
