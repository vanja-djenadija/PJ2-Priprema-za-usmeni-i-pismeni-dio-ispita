package R20210908.Z01;

public class Vrsta implements Element {

    String naziv;

    public Vrsta(String naziv) {
        this.naziv = naziv;
    }

}