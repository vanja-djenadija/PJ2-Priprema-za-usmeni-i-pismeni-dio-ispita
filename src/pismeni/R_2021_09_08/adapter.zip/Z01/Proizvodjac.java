package R20210908.Z01;

public class Proizvodjac implements Element {
    String naziv;

    public Proizvodjac(String naziv) {
        this.naziv = naziv;
    }
}