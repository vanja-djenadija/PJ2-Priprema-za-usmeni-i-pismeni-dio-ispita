package R20210908.Z01;

import java.io.Serializable;

public interface Element extends Serializable {
}